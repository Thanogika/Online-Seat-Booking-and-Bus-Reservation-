<aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
		  
<!-- 	<div class="user-panel">
            <div class="pull-left image">
              <img src="" class="user-image left-sid" >
            </div>
            <div class="pull-left info">
              <p>admin</p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div> -->
		  
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <div style="padding: 20px" ></div>
        
             <ul class="sidebar-menu">
			 
			 
			       <!-- <li class="treeview">
					  <a href="#">
						<i class="fa fa-bus"></i> <span>Bus Management</span><i class="fa fa-angle-left pull-right"></i>
					  </a>
					  <ul class="treeview-menu">
						<li><a href=""><i class="fa fa-circle-o text-aqua"></i>View All</a></li>
						<li><a href=""><i class="fa fa-circle-o text-aqua"></i>Add New Bus</a></li>
						</ul>
                   </li> -->

                   	

                      <li class="treeview">
            <a href="user.php">
            <i class="fa fa-users"></i> <span>View Customer Details</span><i class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="treeview-menu">
            <li><a href="user.php"><i class="fa fa-circle-o text-aqua"></i>View All</a></li>
           <!--  <li><a href="ViewUserr.php"><i class="fa fa-circle-o text-aqua"></i>Add New Bus</a></li> -->
            </ul>
                   </li>																  

                        																	   <li>
                          

                         <li class="treeview">
            <a href="#">
            <i class="fa fa-user"></i> <span>Staff Management</span><i class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="treeview-menu">
            <li><a href="stafff.php"><i class="fa fa-circle-o text-aqua"></i>View All</a></li>
            <li><a href="createstaff.php"><i class="fa fa-circle-o text-aqua"></i>Add New Staff</a></li>
            </ul>
                   </li>

                        <li>
						   <a href="" ><i class=" fa fa-bus"aria-hidden="true"></i><span>Seat Booking Details</span></a>                     
                        </li>

              <!-- fa fa-tint -->
                            <li class="treeview">
            <a href="#">
            <i class="fa fa-bus"></i> <span>Bus Reservation Details</span><i class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="treeview-menu">
            <li><a href="reservation.php"><i class="fa fa-circle-o text-aqua"></i>View All</a></li>
         
            </ul>
                   </li>


                        <li class="treeview">
            <a href="#">
            <i class="fa fa-star"></i> <span>Feedbacks</span><i class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="treeview-menu">
            <li><a href="feedback.php"><i class="fa fa-circle-o text-aqua"></i>View All</a></li>
         
            </ul>
                   </li>
                     

                        <li class="treeview">
            <a href="#">
            <i class="  fa fa-bell"></i> <span>Notifications</span><i class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="treeview-menu">
            <li><a href="notifications.php"><i class="fa fa-circle-o text-aqua"></i>View All</a></li>
          <li><a href="createnotifications.php"><i class="fa fa-circle-o text-aqua"></i>Add New  Notification</a></li>
         
            </ul>
                   </li>
				 </ul>
        </section>
        <!-- /.sidebar -->
      </aside>