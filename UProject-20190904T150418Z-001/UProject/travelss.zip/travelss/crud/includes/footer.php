<!DOCTYPE html>
<html>
<head>

<style>
* {
			box-sizing: border-box;
		}
		.header::after {
			content: "";
			clear: both;
			display: table;
		}
		
		.instrument type::after {
			content: "";
			clear: both;
			display: table;
		}
		
		[class*="col-"] {
			float: left;
			padding: 15px;
		}
		
		.col-1 {width: 8.33%;}
		.col-2 {width: 16.66%;}
		.col-3 {width: 25%;}
		.col-4 {width: 33.33%;}
		.col-5 {width: 41.66%;}
		.col-6 {width: 50%;}
		.col-7 {width: 58.33%;}
		.col-8 {width: 66.66%;}
		.col-9 {width: 75%;}
		.col-10 {width: 83.33%;}
		.col-11 {width: 91.66%;}
		.col-12 {width: 100%;}
.footer{
			background-color:#a2c3c3 ;
			padding:0.1%;
			border-radius: 2px;
			margin-bottom:10px;
			font-size:20px;
			line-height:10px;
			color:black;
		}
		

</style>
	
<body>
<div class="footer col-12">

<div class="address col-3"style="padding-left:50px">
		<address>No-05,</br>
		Central Road,</br>
		Badulla.</address>
</div>
<div class="address col-3">		
		<a href="#1">E-Dilmi@gmail.com</a>
</div>
<div class="address col-3">
		<p>+947678952474</p> </br></br>
		<p>+944709565432</p>
</div>

<div class="address col-3" align="center">
		<p style="text-align:right; padding-right:100px ">E-Dilmi&copy2k19 </p>
</div>	
</div>





</body>
</html>