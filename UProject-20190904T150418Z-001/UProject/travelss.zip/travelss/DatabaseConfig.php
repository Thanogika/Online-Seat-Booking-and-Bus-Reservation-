<?php

//Define your host here.
$HostName = "localhost";

//Define your database username here.
$HostUser = "id10706505_roch";

//Define your database password here.
$HostPass = "roch123";

//Define your database name here.
$DatabaseName = "id10706505_travels";

?>